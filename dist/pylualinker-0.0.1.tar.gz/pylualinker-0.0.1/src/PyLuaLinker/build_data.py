from pathlib import Path
import utils

class build_data:
    def __init__(self,
                 app_name: str,
                 entry_point: str,
                 src_dir: Path,
                 build_dir: Path
                 ) -> None:
        
        self.src = utils.collect_sources(src_dir)

        if not entry_point in self.src:
            print("entry  point not found!")
            exit()
        
        self.app_name = app_name
        self.entry_point = entry_point

        self.build_dir = build_dir
        self.cache_dir = build_dir / ".cache"

    def __init__(self,
                 buildscript:dict,
                 build_dir: Path
                 ) -> None:
        
        build_data(
            buildscript["app_name"],
            "main",
            buildscript["src_dir"],
            build_dir.parent / "build"
        )