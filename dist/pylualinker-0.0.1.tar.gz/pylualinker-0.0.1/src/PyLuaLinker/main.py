import sys
from pathlib import Path
import os
import tree as dt
import linker
from build_data import build_data
import utils


def main():
    print("\nStarting LUA linker...\n")

    execution_path = sys.argv[0]
    buildscript_path = Path(sys.argv[1]).resolve()

    os.chdir(str(buildscript_path.parent))

    buildscript = utils.json_from_path(buildscript_path)

    data = build_data(
        buildscript,
        buildscript_path
    )

    tree = dt.tree(data)
    linker.link_project(data, tree)


if __name__ == "__main__":
    main()
