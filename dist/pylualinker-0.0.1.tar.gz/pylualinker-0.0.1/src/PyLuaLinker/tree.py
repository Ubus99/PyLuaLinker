from node import node
from build_data import build_data

class tree:
    def __init__(self, data:build_data) -> None:
        print("initializing tree for " + data.entry_point + ":\n")

        self.data = data

        self.grow()
        print("tree for " + data.entry_point + " was initialized\n")

    def grow(self):
        print("build tree for" + self.data.entry_point)
        self.root = node(self.data.entry_point, self)
        self.root.grow()

    def get_leaves(self) -> list[node]:
        if self.root == None:
            return []
        
        return self.root.get_leaves()
            
    def cull(self, node: node):
        if node == self.root:
            self.root = None
            return

        self.root.cull(node)