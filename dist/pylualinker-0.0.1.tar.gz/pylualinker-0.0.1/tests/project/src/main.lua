p = require("primary") --> static
s = require("secondary") --> static